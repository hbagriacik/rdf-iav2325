# Rudolf-Diesel-Fachschule Nürnberg <br> Staatlich geprüfter Informatiktechniker

### 1 / 4 - Semester
### IAV 1
1 - <a href="https://github.com/hbagriacik/rdf-iav2325/tree/main/IAV_1/BSA-IAV2324%20(RDF%20Github%20Acc%20Sync)">Betriebssysteme und Administration (BSA)</a><br>
2 - <a href="https://github.com/hbagriacik/rdf-iav2325/tree/main/IAV_1/INA-IAV2324">Internetanwendung (INA)</a><br>
3 - <a href="https://github.com/hbagriacik/rdf-iav2325/tree/main/IAV_1/PRO-IAV2324">Programmieren (PRO)</a><br>
4 - <a href="https://github.com/hbagriacik/rdf-iav2325/tree/main/IAV_1/DB-IAV2324">Datenbanken (DB)</a><br>

<hr>

### 2 / 4 - Semester
### IAV 2
1 - <a href="">?</a><br>
2 - <a href="">?</a><br>
3 - <a href="https://github.com/hbagriacik/rdf-iav2325/tree/main/IAV_2/PRO-IAV24">Programmieren (PRO)</a><br>

<hr>

### 3 / 4 - Semester
### IAV 3
1 - <a href="">?</a><br>
2 - <a href="">?</a><br>
3 - <a href="">?</a><br>

<hr>

### 4 / 4 - Semester
### IAV 4
1 - <a href="">?</a><br>
2 - <a href="">?</a><br>
3 - <a href="">?</a><br>