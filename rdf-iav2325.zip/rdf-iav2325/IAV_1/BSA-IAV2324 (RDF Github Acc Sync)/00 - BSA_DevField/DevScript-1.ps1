# Output String on console
Write-Host "Alles fertig." 


# Output String Variable on console
$variable = "Ich bin eine Variable"
Write-Host $variable