# Rudolf-Diesel-Fachschule Nürnberg <br> Betriebssysteme und Administration (BSA)
