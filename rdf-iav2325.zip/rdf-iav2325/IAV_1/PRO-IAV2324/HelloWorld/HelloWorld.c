#include<stdio.h>

// 1) HelloWorld Programing
int main(){
    
    printf("Hallo World");
    
    getchar();
    return 0;
}