#include <stdio.h>

int main () {

    //CODE

    getchar();
    return 0;
}