#include <stdio.h>


// Aufgabe 1 von CharArraysUebungen.jpg
int main(){



    getchar();
    return 0;
}